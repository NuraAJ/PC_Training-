
package bridges;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author nura aljaafari
 */
public class Bridges {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        Scanner scan = new Scanner (new File("bridges.in"));
        FileWriter fw = new FileWriter("bridges.out");
        PrintWriter pw = new PrintWriter(fw);
        ArrayList <Integer> arrival = new ArrayList<>(); //already sorted 
        ArrayList <Integer> depart = new ArrayList<>(); 
        int T= scan.nextInt();
        int N; 
        int arriveT, durationT, departTime; 
        int noGuests, max_guests;
        int arrivalCounter, counterJ;
        for(int i = 1; i <=T; i++){
            N= scan.nextInt();
            //Reading the arrival & calculate the exit time
            for(int j = 0; j < N; j++){
                arriveT = scan.nextInt();
                durationT = scan.nextInt();
                departTime = arriveT + durationT; 
                
                arrival.add(arriveT); 
                depart.add(departTime);
            }
            Collections.sort(depart); 
            //Checking if reading is correct 
            /*
            for(int k= 0; k<arrival.size(); k++){
                System.out.print(arrival.get(k));
                System.out.println("\t"+depart.get(k));
            }
            */
            // noGuests indicates number of guests at a time 
            noGuests = 1;
            max_guests = 1; 
            arrivalCounter = 1;
            counterJ = 0;
            while (arrivalCounter < N && counterJ < N) { 

            if (arrival.get(arrivalCounter) <= depart.get(counterJ)){ 
                noGuests++; 
                // Update max_guests if needed 
                if (noGuests > max_guests) { 
                    max_guests = noGuests; 
                } 
                arrivalCounter++; //increment index of arrival array 
            } 
            else{ // decrement the number of guests since one must have left 
            noGuests--; 
            counterJ++; 
            } 
            } 
  
            //System.out.println("Maximum Number of Guests = "+max_guests); 
            pw.printf("%d. %d",i, max_guests);
            pw.println();
            //clear the arrays 
            arrival.clear();
            depart.clear();
        }
        pw.close();
    }
    
}
